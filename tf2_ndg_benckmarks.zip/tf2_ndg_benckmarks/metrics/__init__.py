"""
    metrics

    Metrics module.

    Copyright:
        Copyright 2019 by Katsuya SHIMABUKURO.
    License:
        MIT, see LICENSE for details.
"""
