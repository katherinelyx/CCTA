"""
    tf2-ndg-benchmarks

    Neural Dialogue Generation Benchmarks implemented TensorFlow 2.0.

    Copyright:
        Copyright 2019 by Katsuya SHIMABUKURO.
    License:
        MIT, see LICENSE for details.
"""

__version__ = '0.1.0'
